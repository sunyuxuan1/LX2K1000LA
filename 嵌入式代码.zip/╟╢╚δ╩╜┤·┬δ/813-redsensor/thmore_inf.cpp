#include "thmore_inf.h"
#include "ui_thmore_inf.h"
#include "mainwindow.h"
extern int maxTemperature;
extern int minTemperature;
extern int maxHumidity;
extern int minHumidity;
THmore_inf::THmore_inf(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::THmore_inf)
{
    ui->setupUi(this);
    setWindowTitle("更多信息");

}

THmore_inf::~THmore_inf()
{
    delete ui;
}
void THmore_inf::showmore()
{

    ui->label_MAXT ->setText(QString::number(maxTemperature));
    ui->label_MAXT ->show();
   ui->label_MAXH ->setText(QString::number(maxHumidity));
    ui->label_MAXH ->show();
    ui->label_MINT ->setText(QString::number(minTemperature));
    ui->label_MINT ->show();
    ui->label_MINH ->setText(QString::number(minHumidity));
    ui->label_MINH ->show();
    move(800,400);

    show();

}
