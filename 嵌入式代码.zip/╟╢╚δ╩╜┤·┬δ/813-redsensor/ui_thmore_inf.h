/********************************************************************************
** Form generated from reading UI file 'thmore_inf.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_THMORE_INF_H
#define UI_THMORE_INF_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_THmore_inf
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_MAXT;
    QLabel *label_MINT;
    QLabel *label_MAXH;
    QLabel *label_MINH;

    void setupUi(QWidget *THmore_inf)
    {
        if (THmore_inf->objectName().isEmpty())
            THmore_inf->setObjectName(QString::fromUtf8("THmore_inf"));
        THmore_inf->resize(434, 375);
        THmore_inf->setStyleSheet(QString::fromUtf8("background-color: rgb(233, 185, 110);"));
        label = new QLabel(THmore_inf);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(50, 80, 201, 41));
        label->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";"));
        label_2 = new QLabel(THmore_inf);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(50, 130, 211, 41));
        label_2->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";"));
        label_4 = new QLabel(THmore_inf);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(50, 180, 211, 41));
        label_4->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";"));
        label_5 = new QLabel(THmore_inf);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(50, 230, 201, 51));
        label_5->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";"));
        label_MAXT = new QLabel(THmore_inf);
        label_MAXT->setObjectName(QString::fromUtf8("label_MAXT"));
        label_MAXT->setGeometry(QRect(260, 88, 81, 31));
        label_MAXT->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";\n"
"background-color: rgb(238, 238, 236);\n"
""));
        label_MINT = new QLabel(THmore_inf);
        label_MINT->setObjectName(QString::fromUtf8("label_MINT"));
        label_MINT->setGeometry(QRect(260, 140, 81, 31));
        label_MINT->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";\n"
"background-color: rgb(255, 255, 255);"));
        label_MAXH = new QLabel(THmore_inf);
        label_MAXH->setObjectName(QString::fromUtf8("label_MAXH"));
        label_MAXH->setGeometry(QRect(260, 190, 81, 31));
        label_MAXH->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";\n"
"background-color: rgb(238, 238, 236);"));
        label_MINH = new QLabel(THmore_inf);
        label_MINH->setObjectName(QString::fromUtf8("label_MINH"));
        label_MINH->setGeometry(QRect(260, 240, 81, 31));
        label_MINH->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";\n"
"background-color: rgb(238, 238, 236);"));

        retranslateUi(THmore_inf);

        QMetaObject::connectSlotsByName(THmore_inf);
    } // setupUi

    void retranslateUi(QWidget *THmore_inf)
    {
        THmore_inf->setWindowTitle(QCoreApplication::translate("THmore_inf", "Form", nullptr));
        label->setText(QCoreApplication::translate("THmore_inf", "\346\234\200\351\253\230\346\270\251\345\272\246(\302\260C)", nullptr));
        label_2->setText(QCoreApplication::translate("THmore_inf", "\346\234\200\344\275\216\346\270\251\345\272\246(\302\260C)", nullptr));
        label_4->setText(QCoreApplication::translate("THmore_inf", "\346\234\200\351\253\230\346\271\277\345\272\246(%)", nullptr));
        label_5->setText(QCoreApplication::translate("THmore_inf", "\346\234\200\344\275\216\346\271\277\345\272\246(%)", nullptr));
        label_MAXT->setText(QString());
        label_MINT->setText(QString());
        label_MAXH->setText(QString());
        label_MINH->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class THmore_inf: public Ui_THmore_inf {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_THMORE_INF_H
