#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "red_sensor.h"
#include "thmore_inf.h"

namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
    red_sensor* kaiguan;
    void redsensor();
    void ReceiveSerial();
    void MPU6050();
    QTimer* timer;
    QTimer* timer2;
    QTimer* timer3;
    QTimer* timer4;
    void StartTimer1();
    void StopTimer1();
    void StartTimer2();
    void StopTimer2();
    void StartTimer3();
    void StopTimer3();
    void aliyuntest();
    void dateandtime();


    THmore_inf* moreinf;

};
#endif // MAINWINDOW_H
