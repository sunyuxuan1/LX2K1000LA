/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QFrame *frame;
    QPushButton *open_redsensor;
    QPushButton *close_redsensor;
    QLabel *label_2;
    QLabel *label_redsensor;
    QLabel *label_3;
    QLabel *label_redsensor_2;
    QLabel *label_22;
    QFrame *frame_2;
    QLabel *label_6;
    QPushButton *open_HTsensor_more;
    QPushButton *open_HTsensor;
    QLabel *label_5;
    QLabel *label_HTsensor;
    QPushButton *close_HTsensor;
    QLabel *label_4;
    QLabel *label_16;
    QFrame *line;
    QFrame *line_2;
    QLabel *label_17;
    QLabel *label_18;
    QLabel *label_19;
    QLabel *label_HTsensor_2;
    QLabel *WDstate;
    QLabel *SDstate;
    QLineEdit *lineEdit_LT;
    QLineEdit *lineEdit_HT;
    QLineEdit *lineEdit_LH;
    QLineEdit *lineEdit_HH;
    QFrame *frame_3;
    QPushButton *open_MPU6050;
    QPushButton *close_MPU6050;
    QLabel *MP6050_wz;
    QLabel *label_13;
    QLabel *label_15;
    QFrame *frame_4;
    QPushButton *closeAll;
    QPushButton *openAll;
    QPushButton *Ali_yun;
    QPushButton *Ali_yun_2;
    QLabel *label_21;
    QTextEdit *textEdit;
    QLabel *time;
    QLabel *label_24;
    QLabel *label_HTsensor_3;
    QPushButton *Ali_yun_3;
    QLabel *label_23;
    QLabel *label_25;
    QMenuBar *menubar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(2385, 1516);
        MainWindow->setMouseTracking(false);
        MainWindow->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 248, 220);\n"
"QHeaderView::title { font-size: 16px; }"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        frame = new QFrame(centralwidget);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(880, 260, 351, 281));
        frame->setStyleSheet(QString::fromUtf8("background-color: rgb(108, 255, 249);"));
        frame->setFrameShape(QFrame::Panel);
        frame->setFrameShadow(QFrame::Raised);
        frame->setLineWidth(10);
        frame->setMidLineWidth(6);
        open_redsensor = new QPushButton(frame);
        open_redsensor->setObjectName(QString::fromUtf8("open_redsensor"));
        open_redsensor->setGeometry(QRect(20, 70, 101, 41));
        open_redsensor->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";\n"
""));
        close_redsensor = new QPushButton(frame);
        close_redsensor->setObjectName(QString::fromUtf8("close_redsensor"));
        close_redsensor->setGeometry(QRect(210, 70, 101, 41));
        close_redsensor->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";"));
        label_2 = new QLabel(frame);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(30, 130, 161, 61));
        label_2->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";"));
        label_redsensor = new QLabel(frame);
        label_redsensor->setObjectName(QString::fromUtf8("label_redsensor"));
        label_redsensor->setGeometry(QRect(190, 140, 131, 41));
        label_redsensor->setStyleSheet(QString::fromUtf8("background-color: rgb(211, 215, 207);\n"
"font: 20pt \"Cantarell\";"));
        label_redsensor->setFrameShape(QFrame::WinPanel);
        label_redsensor->setFrameShadow(QFrame::Sunken);
        label_redsensor->setLineWidth(1);
        label_redsensor->setMidLineWidth(-1);
        label_redsensor->setTextFormat(Qt::AutoText);
        label_redsensor->setMargin(0);
        label_redsensor->setIndent(-1);
        label_3 = new QLabel(frame);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(30, 200, 91, 31));
        label_3->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";"));
        label_redsensor_2 = new QLabel(frame);
        label_redsensor_2->setObjectName(QString::fromUtf8("label_redsensor_2"));
        label_redsensor_2->setGeometry(QRect(190, 190, 141, 41));
        label_redsensor_2->setStyleSheet(QString::fromUtf8("background-color: rgb(211, 215, 207);\n"
"font: 20pt \"Cantarell\";\n"
""));
        label_redsensor_2->setFrameShape(QFrame::WinPanel);
        label_redsensor_2->setFrameShadow(QFrame::Sunken);
        label_redsensor_2->setLineWidth(1);
        label_redsensor_2->setMidLineWidth(-1);
        label_redsensor_2->setTextFormat(Qt::AutoText);
        label_redsensor_2->setMargin(0);
        label_redsensor_2->setIndent(-1);
        label_22 = new QLabel(frame);
        label_22->setObjectName(QString::fromUtf8("label_22"));
        label_22->setGeometry(QRect(20, 20, 261, 61));
        label_22->setStyleSheet(QString::fromUtf8("font: 25pt \"Cantarell\";\n"
"\n"
"color: rgb(143, 89, 2);\n"
""));
        label_22->setTextFormat(Qt::AutoText);
        frame_2 = new QFrame(centralwidget);
        frame_2->setObjectName(QString::fromUtf8("frame_2"));
        frame_2->setGeometry(QRect(880, 610, 351, 841));
        frame_2->setStyleSheet(QString::fromUtf8("background-color: rgb(2, 212, 106);"));
        frame_2->setFrameShape(QFrame::Panel);
        frame_2->setFrameShadow(QFrame::Raised);
        frame_2->setLineWidth(10);
        label_6 = new QLabel(frame_2);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(50, 20, 261, 61));
        label_6->setStyleSheet(QString::fromUtf8("font: 25pt \"Cantarell\";\n"
"\n"
"color: rgb(143, 89, 2);\n"
""));
        label_6->setTextFormat(Qt::AutoText);
        open_HTsensor_more = new QPushButton(frame_2);
        open_HTsensor_more->setObjectName(QString::fromUtf8("open_HTsensor_more"));
        open_HTsensor_more->setGeometry(QRect(30, 760, 151, 51));
        open_HTsensor_more->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";"));
        open_HTsensor = new QPushButton(frame_2);
        open_HTsensor->setObjectName(QString::fromUtf8("open_HTsensor"));
        open_HTsensor->setGeometry(QRect(30, 80, 101, 41));
        open_HTsensor->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";"));
        label_5 = new QLabel(frame_2);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(30, 200, 141, 31));
        label_5->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";"));
        label_HTsensor = new QLabel(frame_2);
        label_HTsensor->setObjectName(QString::fromUtf8("label_HTsensor"));
        label_HTsensor->setGeometry(QRect(200, 140, 121, 41));
        label_HTsensor->setStyleSheet(QString::fromUtf8("background-color: rgb(211, 215, 207);\n"
"font: 20pt \"Cantarell\";"));
        label_HTsensor->setFrameShape(QFrame::WinPanel);
        label_HTsensor->setFrameShadow(QFrame::Sunken);
        label_HTsensor->setLineWidth(1);
        label_HTsensor->setMidLineWidth(-1);
        label_HTsensor->setTextFormat(Qt::AutoText);
        label_HTsensor->setMargin(0);
        label_HTsensor->setIndent(-1);
        close_HTsensor = new QPushButton(frame_2);
        close_HTsensor->setObjectName(QString::fromUtf8("close_HTsensor"));
        close_HTsensor->setGeometry(QRect(200, 80, 101, 41));
        close_HTsensor->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";"));
        label_4 = new QLabel(frame_2);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(30, 130, 141, 61));
        label_4->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";"));
        label_16 = new QLabel(frame_2);
        label_16->setObjectName(QString::fromUtf8("label_16"));
        label_16->setGeometry(QRect(40, 280, 261, 31));
        label_16->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";"));
        line = new QFrame(frame_2);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(150, 340, 41, 16));
        line->setFrameShadow(QFrame::Plain);
        line->setLineWidth(3);
        line->setFrameShape(QFrame::HLine);
        line_2 = new QFrame(frame_2);
        line_2->setObjectName(QString::fromUtf8("line_2"));
        line_2->setGeometry(QRect(150, 450, 41, 16));
        line_2->setFrameShadow(QFrame::Plain);
        line_2->setLineWidth(3);
        line_2->setFrameShape(QFrame::HLine);
        label_17 = new QLabel(frame_2);
        label_17->setObjectName(QString::fromUtf8("label_17"));
        label_17->setGeometry(QRect(40, 390, 261, 31));
        label_17->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";"));
        label_18 = new QLabel(frame_2);
        label_18->setObjectName(QString::fromUtf8("label_18"));
        label_18->setGeometry(QRect(30, 570, 141, 31));
        label_18->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";"));
        label_19 = new QLabel(frame_2);
        label_19->setObjectName(QString::fromUtf8("label_19"));
        label_19->setGeometry(QRect(30, 660, 141, 31));
        label_19->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";"));
        label_HTsensor_2 = new QLabel(frame_2);
        label_HTsensor_2->setObjectName(QString::fromUtf8("label_HTsensor_2"));
        label_HTsensor_2->setGeometry(QRect(200, 200, 121, 41));
        label_HTsensor_2->setStyleSheet(QString::fromUtf8("background-color: rgb(211, 215, 207);\n"
"font: 20pt \"Cantarell\";"));
        label_HTsensor_2->setFrameShape(QFrame::WinPanel);
        label_HTsensor_2->setFrameShadow(QFrame::Sunken);
        label_HTsensor_2->setLineWidth(1);
        label_HTsensor_2->setMidLineWidth(-1);
        label_HTsensor_2->setTextFormat(Qt::AutoText);
        label_HTsensor_2->setMargin(0);
        label_HTsensor_2->setIndent(-1);
        WDstate = new QLabel(frame_2);
        WDstate->setObjectName(QString::fromUtf8("WDstate"));
        WDstate->setGeometry(QRect(200, 560, 121, 41));
        WDstate->setStyleSheet(QString::fromUtf8("background-color: rgb(211, 215, 207);\n"
"font: 20pt \"Cantarell\";"));
        WDstate->setFrameShape(QFrame::WinPanel);
        WDstate->setFrameShadow(QFrame::Sunken);
        WDstate->setLineWidth(1);
        WDstate->setMidLineWidth(-1);
        WDstate->setTextFormat(Qt::AutoText);
        WDstate->setMargin(0);
        WDstate->setIndent(-1);
        SDstate = new QLabel(frame_2);
        SDstate->setObjectName(QString::fromUtf8("SDstate"));
        SDstate->setGeometry(QRect(200, 650, 121, 41));
        SDstate->setStyleSheet(QString::fromUtf8("background-color: rgb(211, 215, 207);\n"
"font: 20pt \"Cantarell\";"));
        SDstate->setFrameShape(QFrame::WinPanel);
        SDstate->setFrameShadow(QFrame::Sunken);
        SDstate->setLineWidth(1);
        SDstate->setMidLineWidth(-1);
        SDstate->setTextFormat(Qt::AutoText);
        SDstate->setMargin(0);
        SDstate->setIndent(-1);
        lineEdit_LT = new QLineEdit(frame_2);
        lineEdit_LT->setObjectName(QString::fromUtf8("lineEdit_LT"));
        lineEdit_LT->setGeometry(QRect(20, 330, 121, 41));
        lineEdit_LT->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";\n"
"background-color: rgb(211, 215, 207);"));
        lineEdit_HT = new QLineEdit(frame_2);
        lineEdit_HT->setObjectName(QString::fromUtf8("lineEdit_HT"));
        lineEdit_HT->setGeometry(QRect(200, 330, 121, 41));
        lineEdit_HT->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";\n"
"background-color: rgb(211, 215, 207);"));
        lineEdit_LH = new QLineEdit(frame_2);
        lineEdit_LH->setObjectName(QString::fromUtf8("lineEdit_LH"));
        lineEdit_LH->setGeometry(QRect(20, 440, 121, 41));
        lineEdit_LH->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";\n"
"background-color: rgb(211, 215, 207);"));
        lineEdit_HH = new QLineEdit(frame_2);
        lineEdit_HH->setObjectName(QString::fromUtf8("lineEdit_HH"));
        lineEdit_HH->setGeometry(QRect(200, 440, 121, 41));
        lineEdit_HH->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";\n"
"background-color: rgb(211, 215, 207);"));
        frame_3 = new QFrame(centralwidget);
        frame_3->setObjectName(QString::fromUtf8("frame_3"));
        frame_3->setGeometry(QRect(1380, 260, 641, 281));
        frame_3->setStyleSheet(QString::fromUtf8("background-color: rgb(108, 255, 249);"));
        frame_3->setFrameShape(QFrame::Panel);
        frame_3->setFrameShadow(QFrame::Raised);
        frame_3->setLineWidth(10);
        open_MPU6050 = new QPushButton(frame_3);
        open_MPU6050->setObjectName(QString::fromUtf8("open_MPU6050"));
        open_MPU6050->setGeometry(QRect(40, 150, 101, 41));
        open_MPU6050->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";"));
        close_MPU6050 = new QPushButton(frame_3);
        close_MPU6050->setObjectName(QString::fromUtf8("close_MPU6050"));
        close_MPU6050->setGeometry(QRect(180, 150, 101, 41));
        close_MPU6050->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";"));
        MP6050_wz = new QLabel(frame_3);
        MP6050_wz->setObjectName(QString::fromUtf8("MP6050_wz"));
        MP6050_wz->setGeometry(QRect(400, 100, 181, 41));
        MP6050_wz->setStyleSheet(QString::fromUtf8("background-color: rgb(211, 215, 207);\n"
"font: 20pt \"Cantarell\";"));
        MP6050_wz->setFrameShape(QFrame::WinPanel);
        MP6050_wz->setFrameShadow(QFrame::Sunken);
        MP6050_wz->setLineWidth(1);
        MP6050_wz->setMidLineWidth(-1);
        MP6050_wz->setTextFormat(Qt::AutoText);
        MP6050_wz->setMargin(0);
        MP6050_wz->setIndent(-1);
        label_13 = new QLabel(frame_3);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(300, 80, 71, 71));
        label_13->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";"));
        label_15 = new QLabel(frame_3);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setGeometry(QRect(100, 50, 141, 61));
        label_15->setStyleSheet(QString::fromUtf8("font: 25pt \"Cantarell\";\n"
"\n"
"color: rgb(143, 89, 2);\n"
""));
        label_15->setTextFormat(Qt::AutoText);
        frame_4 = new QFrame(centralwidget);
        frame_4->setObjectName(QString::fromUtf8("frame_4"));
        frame_4->setGeometry(QRect(1380, 620, 641, 291));
        frame_4->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        frame_4->setFrameShape(QFrame::Panel);
        frame_4->setFrameShadow(QFrame::Raised);
        frame_4->setLineWidth(5);
        closeAll = new QPushButton(frame_4);
        closeAll->setObjectName(QString::fromUtf8("closeAll"));
        closeAll->setGeometry(QRect(80, 170, 161, 41));
        closeAll->setStyleSheet(QString::fromUtf8("\n"
"font: 20pt \"Cantarell\";"));
        openAll = new QPushButton(frame_4);
        openAll->setObjectName(QString::fromUtf8("openAll"));
        openAll->setGeometry(QRect(80, 90, 161, 41));
        openAll->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";"));
        Ali_yun = new QPushButton(frame_4);
        Ali_yun->setObjectName(QString::fromUtf8("Ali_yun"));
        Ali_yun->setGeometry(QRect(350, 90, 181, 41));
        Ali_yun->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";"));
        Ali_yun_2 = new QPushButton(frame_4);
        Ali_yun_2->setObjectName(QString::fromUtf8("Ali_yun_2"));
        Ali_yun_2->setGeometry(QRect(350, 170, 181, 41));
        Ali_yun_2->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";"));
        label_21 = new QLabel(frame_4);
        label_21->setObjectName(QString::fromUtf8("label_21"));
        label_21->setGeometry(QRect(170, 10, 321, 61));
        label_21->setStyleSheet(QString::fromUtf8("font: 25pt \"Cantarell\";\n"
"\n"
"color: rgb(143, 89, 2);\n"
""));
        label_21->setTextFormat(Qt::AutoText);
        textEdit = new QTextEdit(centralwidget);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(1370, 940, 641, 511));
        textEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(251, 210, 107);"));
        textEdit->setFrameShape(QFrame::Panel);
        textEdit->setLineWidth(10);
        time = new QLabel(centralwidget);
        time->setObjectName(QString::fromUtf8("time"));
        time->setGeometry(QRect(1090, 160, 491, 71));
        time->setStyleSheet(QString::fromUtf8("color: rgb(136, 138, 133);\n"
"font: 24pt \"Cantarell\";"));
        label_24 = new QLabel(centralwidget);
        label_24->setObjectName(QString::fromUtf8("label_24"));
        label_24->setGeometry(QRect(1410, 1110, 281, 41));
        label_24->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";"));
        label_HTsensor_3 = new QLabel(centralwidget);
        label_HTsensor_3->setObjectName(QString::fromUtf8("label_HTsensor_3"));
        label_HTsensor_3->setGeometry(QRect(1780, 1110, 151, 41));
        label_HTsensor_3->setStyleSheet(QString::fromUtf8("background-color: rgb(211, 215, 207);\n"
"font: 20pt \"Cantarell\";"));
        label_HTsensor_3->setFrameShape(QFrame::WinPanel);
        label_HTsensor_3->setFrameShadow(QFrame::Sunken);
        label_HTsensor_3->setLineWidth(1);
        label_HTsensor_3->setMidLineWidth(-1);
        label_HTsensor_3->setTextFormat(Qt::AutoText);
        label_HTsensor_3->setMargin(0);
        label_HTsensor_3->setIndent(-1);
        Ali_yun_3 = new QPushButton(centralwidget);
        Ali_yun_3->setObjectName(QString::fromUtf8("Ali_yun_3"));
        Ali_yun_3->setGeometry(QRect(1510, 1240, 421, 41));
        Ali_yun_3->setStyleSheet(QString::fromUtf8("font: 20pt \"Cantarell\";"));
        label_23 = new QLabel(centralwidget);
        label_23->setObjectName(QString::fromUtf8("label_23"));
        label_23->setGeometry(QRect(1560, 980, 321, 61));
        label_23->setTabletTracking(false);
        label_23->setAcceptDrops(false);
        label_23->setStyleSheet(QString::fromUtf8("font: 25pt \"Cantarell\";\n"
"\n"
"color: rgb(143, 89, 2);\n"
""));
        label_23->setTextFormat(Qt::AutoText);
        label_23->setOpenExternalLinks(false);
        label_25 = new QLabel(centralwidget);
        label_25->setObjectName(QString::fromUtf8("label_25"));
        label_25->setGeometry(QRect(1050, 80, 801, 61));
        label_25->setStyleSheet(QString::fromUtf8("font: 25pt \"Cantarell\";\n"
"\n"
"color: rgb(144, 0, 33);\n"
""));
        label_25->setTextFormat(Qt::AutoText);
        MainWindow->setCentralWidget(centralwidget);
        frame_4->raise();
        frame_2->raise();
        frame_3->raise();
        frame->raise();
        textEdit->raise();
        time->raise();
        label_24->raise();
        label_HTsensor_3->raise();
        Ali_yun_3->raise();
        label_23->raise();
        label_25->raise();
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 2385, 25));
        MainWindow->setMenuBar(menubar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);
#if QT_CONFIG(shortcut)
#endif // QT_CONFIG(shortcut)

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        open_redsensor->setText(QCoreApplication::translate("MainWindow", "\346\211\223\345\274\200", nullptr));
        close_redsensor->setText(QCoreApplication::translate("MainWindow", "\345\205\263\351\227\255", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "\350\276\223\345\207\272\347\224\265\345\271\263", nullptr));
        label_redsensor->setText(QCoreApplication::translate("MainWindow", "\351\253\230", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "\347\212\266\346\200\201", nullptr));
        label_redsensor_2->setText(QCoreApplication::translate("MainWindow", "\346\204\237\345\272\224\345\210\260\344\272\272", nullptr));
        label_22->setText(QCoreApplication::translate("MainWindow", "\344\272\272\344\275\223\347\272\242\345\244\226\346\204\237\345\272\224", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "\346\270\251\346\271\277\345\272\246\344\274\240\346\204\237\345\231\250", nullptr));
        open_HTsensor_more->setText(QCoreApplication::translate("MainWindow", "\346\233\264\345\244\232\344\277\241\346\201\257", nullptr));
        open_HTsensor->setText(QCoreApplication::translate("MainWindow", "\346\211\223\345\274\200", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "\346\271\277\345\272\246(%)", nullptr));
        label_HTsensor->setText(QCoreApplication::translate("MainWindow", "24", nullptr));
        close_HTsensor->setText(QCoreApplication::translate("MainWindow", "\345\205\263\351\227\255", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "\346\270\251\345\272\246(\302\260C)", nullptr));
        label_16->setText(QCoreApplication::translate("MainWindow", "\350\256\276\347\275\256\346\255\243\345\270\270\346\270\251\345\272\246\350\214\203\345\233\264(\302\260C)", nullptr));
        label_17->setText(QCoreApplication::translate("MainWindow", "\350\256\276\347\275\256\346\255\243\345\270\270\346\271\277\345\272\246\350\214\203\345\233\264(%)", nullptr));
        label_18->setText(QCoreApplication::translate("MainWindow", "\346\270\251\345\272\246\347\212\266\346\200\201", nullptr));
        label_19->setText(QCoreApplication::translate("MainWindow", "\346\271\277\345\272\246\347\212\266\346\200\201", nullptr));
        label_HTsensor_2->setText(QCoreApplication::translate("MainWindow", "47", nullptr));
        WDstate->setText(QCoreApplication::translate("MainWindow", "\346\255\243\345\270\270", nullptr));
        SDstate->setText(QCoreApplication::translate("MainWindow", "\346\255\243\345\270\270", nullptr));
#if QT_CONFIG(whatsthis)
        lineEdit_LT->setWhatsThis(QCoreApplication::translate("MainWindow", "<html><head/><body><p>wendu</p></body></html>", nullptr));
#endif // QT_CONFIG(whatsthis)
        lineEdit_LT->setText(QCoreApplication::translate("MainWindow", "20", nullptr));
#if QT_CONFIG(whatsthis)
        lineEdit_HT->setWhatsThis(QCoreApplication::translate("MainWindow", "<html><head/><body><p>wendu</p></body></html>", nullptr));
#endif // QT_CONFIG(whatsthis)
        lineEdit_HT->setText(QCoreApplication::translate("MainWindow", "60", nullptr));
#if QT_CONFIG(whatsthis)
        lineEdit_LH->setWhatsThis(QCoreApplication::translate("MainWindow", "<html><head/><body><p>wendu</p></body></html>", nullptr));
#endif // QT_CONFIG(whatsthis)
        lineEdit_LH->setText(QCoreApplication::translate("MainWindow", "40", nullptr));
#if QT_CONFIG(whatsthis)
        lineEdit_HH->setWhatsThis(QCoreApplication::translate("MainWindow", "<html><head/><body><p>wendu</p></body></html>", nullptr));
#endif // QT_CONFIG(whatsthis)
        lineEdit_HH->setText(QCoreApplication::translate("MainWindow", "80", nullptr));
        open_MPU6050->setText(QCoreApplication::translate("MainWindow", "\346\211\223\345\274\200", nullptr));
        close_MPU6050->setText(QCoreApplication::translate("MainWindow", "\345\205\263\351\227\255", nullptr));
        MP6050_wz->setText(QCoreApplication::translate("MainWindow", "\345\205\263\351\227\255", nullptr));
        label_13->setText(QCoreApplication::translate("MainWindow", "\347\212\266\346\200\201", nullptr));
        label_15->setText(QCoreApplication::translate("MainWindow", "\346\212\245\350\255\246\345\231\250", nullptr));
        closeAll->setText(QCoreApplication::translate("MainWindow", "\345\205\250\351\203\250\345\205\263\351\227\255", nullptr));
        openAll->setText(QCoreApplication::translate("MainWindow", "\345\205\250\351\203\250\346\211\223\345\274\200", nullptr));
        Ali_yun->setText(QCoreApplication::translate("MainWindow", "\350\277\236\346\216\245\344\272\221\345\271\263\345\217\260", nullptr));
        Ali_yun_2->setText(QCoreApplication::translate("MainWindow", "\346\226\255\345\274\200\344\272\221\345\271\263\345\217\260", nullptr));
        label_21->setText(QCoreApplication::translate("MainWindow", "\346\200\273\344\275\223\345\212\237\350\203\275\346\216\247\345\210\266\345\214\272", nullptr));
        time->setText(QCoreApplication::translate("MainWindow", "time", nullptr));
        label_24->setText(QCoreApplication::translate("MainWindow", "\344\272\272\345\221\230\350\277\233\345\207\272\346\212\245\350\255\246\346\254\241\346\225\260", nullptr));
        label_HTsensor_3->setText(QString());
        Ali_yun_3->setText(QCoreApplication::translate("MainWindow", "\344\272\272\345\221\230\350\277\233\345\207\272\346\212\223\346\213\215\346\237\245\347\234\213", nullptr));
        label_23->setText(QCoreApplication::translate("MainWindow", "\350\277\234\347\250\213\347\233\221\346\216\247\346\216\247\345\210\266\345\214\272", nullptr));
        label_25->setText(QCoreApplication::translate("MainWindow", "\345\237\272\344\272\216\351\276\231\350\212\2572K1000LA\345\274\200\345\217\221\346\235\277\347\232\204\345\267\245\344\270\232\347\275\221\345\205\263\347\263\273\347\273\237", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
