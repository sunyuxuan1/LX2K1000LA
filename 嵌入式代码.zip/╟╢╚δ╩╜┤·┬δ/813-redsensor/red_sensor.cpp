#include "red_sensor.h"

#include <QDebug>
#include <QProcess>

red_sensor::red_sensor(QObject *parent) : QObject(parent)
{

}

void red_sensor::readdate()
{
    qDebug()<<"红外线传感器检测到障碍物";
    QProcess process;

    // 设置要执行的 Python 脚本路径和参数
    QString pythonPath = "python3";  // 或者使用完整的 Python 解释器路径
    QStringList arguments;
    arguments << "/home/cyy/python/814test.py";

    // 启动 Python 进程
    process.start(pythonPath, arguments);

    // 等待进程执行完成
    process.waitForFinished();

    // 读取进程的输出
    QByteArray output = process.readAllStandardOutput();
    QString outputString = QString::fromLocal8Bit(output);
    outputString.chop(1); // 移除最后一个字符（即换行符）

    // 在控制台输出 Python 进程的输出
    qDebug() << outputString;

}
