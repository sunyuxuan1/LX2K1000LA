#ifndef RED_SENSOR_H
#define RED_SENSOR_H

#include <QObject>

class red_sensor : public QObject
{
    Q_OBJECT
public:
    explicit red_sensor(QObject *parent = nullptr);
public slots:
    void readdate();
};

#endif // RED_SENSOR_H
