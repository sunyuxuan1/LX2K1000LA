#include "mainwindow.h"

#include <QApplication>
#include <QPalette>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.setWindowTitle("基于龙芯2K1000LA的工业物联网网关");
    // 创建QPalette对象，并设置背景色为浅蓝色
//    QPalette palette;
//    palette.setColor(QPalette::Background, QColor(204, 230, 204)); // 使用RGB颜色或Qt提供的预定义颜色

//    QPalette palette;
//    palette.setColor(QPalette::Background, Qt::blue);
//    // 设置主窗口的调色板为创建的QPalette对象
//    w.setPalette(palette);

   // w.setFixedSize(1600,900);

    w.show();

    return a.exec();
}
