#ifndef THMORE_INF_H
#define THMORE_INF_H

#include <QWidget>

namespace Ui {
class THmore_inf;
}

class THmore_inf : public QWidget
{
    Q_OBJECT

public:
    explicit THmore_inf(QWidget *parent = nullptr);
    ~THmore_inf();
    void showmore();
private:
    Ui::THmore_inf *ui;

};

#endif // THMORE_INF_H
