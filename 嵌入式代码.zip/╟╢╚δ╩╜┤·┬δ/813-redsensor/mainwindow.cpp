#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "thmore_inf.h"
#include <QDebug>
#include <QLabel>
#include <QProcess>
#include <QTimer>
#include <qpushbutton.h>

#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>

#include <QDateTime>
 int minTemperature=999;
 int maxTemperature = -999;
 int minHumidity = 999;
 int maxHumidity = -999;


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{

    ui->setupUi(this);
    kaiguan = new red_sensor;
    timer = new QTimer(this);
    timer2 = new QTimer(this);
    timer3 = new QTimer(this);
    //
    timer4 = new QTimer(this);
    timer4->start(100);

    moreinf=new THmore_inf;
    //红外线传感器模块


    //连接红外线开启按钮和计时器启动
    connect(ui->open_redsensor,&QPushButton::clicked,this,&MainWindow::StartTimer1);

    //连接红外线关闭按钮和计时器关闭
    connect(ui->close_redsensor,&QPushButton::clicked,this,&MainWindow::StopTimer1);

    // 连接 timeout 信号和槽函数
    connect(timer, &QTimer::timeout, this, &MainWindow::redsensor);
    //




    //温湿度传感器模块
    //连接红外线开启按钮和计时器启动
    connect(ui->open_HTsensor,&QPushButton::clicked,this,&MainWindow::StartTimer2);

    //连接红外线关闭按钮和计时器关闭
    connect(ui->close_HTsensor,&QPushButton::clicked,this,&MainWindow::StopTimer2);

    // 连接 timeout 信号和槽函数
    connect(timer2, &QTimer::timeout, this, &MainWindow::ReceiveSerial);

    //more
    connect(ui->open_HTsensor_more,&QPushButton::clicked,moreinf,&THmore_inf::showmore);




    //MPU6050
    //连接红外线开启按钮和计时器启动
    connect(ui->open_MPU6050,&QPushButton::clicked,this,&MainWindow::StartTimer3);

    //连接红外线关闭按钮和计时器关闭
    connect(ui->close_MPU6050,&QPushButton::clicked,this,&MainWindow::StopTimer3);

    // 连接 timeout 信号和槽函数
    connect(timer3, &QTimer::timeout, this, &MainWindow::MPU6050);



    //All
    connect(ui->openAll,&QPushButton::clicked,this,&MainWindow::StartTimer1);
    connect(ui->openAll,&QPushButton::clicked,this,&MainWindow::StartTimer2);
    connect(ui->openAll,&QPushButton::clicked,this,&MainWindow::StartTimer3);
    connect(ui->closeAll,&QPushButton::clicked,this,&MainWindow::StopTimer1);
    connect(ui->closeAll,&QPushButton::clicked,this,&MainWindow::StopTimer2);
    connect(ui->closeAll,&QPushButton::clicked,this,&MainWindow::StopTimer3);

    //aliyun
    connect(ui->Ali_yun,&QPushButton::clicked,this,&MainWindow::aliyuntest);





//    QDateTime currentDateTime = QDateTime::currentDateTime();
//    QString currentDateTimeString = currentDateTime.toString("yyyy-MM-dd hh:mm:ss");
//    ui->time->setText(currentDateTimeString);
//    ui->time->show();
    connect(timer4, &QTimer::timeout, this, &MainWindow::dateandtime);


}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::redsensor()
{
    QProcess process;

    // 设置要执行的 Python 脚本路径和参数
    QString pythonPath = "python3";  // 或者使用完整的 Python 解释器路径
    QStringList arguments;
    arguments << "/root/Desktop/gpio38/redsensor.py";

    // 启动 Python 进程
    process.start(pythonPath, arguments);

    // 等待进程执行完成
    process.waitForFinished();

    // 读取进程的输出
    QByteArray output = process.readAllStandardOutput();
    QString outputString = QString::fromLocal8Bit(output);
    outputString.chop(1); // 移除最后一个字符（即换行符）

    // 在控制台输出 Python 进程的输出
    //qDebug() << outputString;
    ui->label_redsensor->setText(outputString);
    ui->label_redsensor->show();
    if(outputString=="0")
    {
        ui->label_redsensor_2->setText("无障碍物");
        ui->label_redsensor_2->setStyleSheet("color: green;" + ui->label_redsensor->styleSheet());
    }
    else if(outputString=="1")
        {
        ui->label_redsensor_2->setText("有障碍物");
        ui->label_redsensor_2->setStyleSheet("color: red;" + ui->label_redsensor->styleSheet());
    }
        ui->label_redsensor_2->show();
}
void MainWindow::StartTimer1()
{
    timer->start(100);
}
void MainWindow::StartTimer2()
{
    timer2->start(100);
}
void MainWindow::StartTimer3()
{
    timer3->start(100);
}

void MainWindow::StopTimer1()
{
    timer->stop();
    //
    ui->label_redsensor->clear();
    ui->label_redsensor_2->clear();
}
void MainWindow::StopTimer2()
{
    timer2->stop();
    //
    ui->WDstate->clear();
    ui->SDstate->clear();
    ui->label_HTsensor->clear();
    ui->label_HTsensor_2->clear();
}
void MainWindow::StopTimer3()
{
    timer3->stop();
    //
    //ui->MP6050_ax->clear();
    //ui->MP6050_ay->clear();
    //ui->MP6050_az->clear();
    //ui->MP6050_wx->clear();
    //ui->MP6050_wy->clear();
    //ui->MP6050_wz->clear();
}


void MainWindow::ReceiveSerial()
{
    QProcess process;

    // 设置要执行的 Python 脚本路径和参数
    QString pythonPath = "python3";  // 或者使用完整的 Python 解释器路径
    QStringList arguments;
    arguments << "/root/Desktop/Serial/serial_test.py";

    // 启动 Python 进程
    process.start(pythonPath, arguments);

    // 等待进程执行完成
    process.waitForFinished();

    // 读取进程的输出
    QByteArray output = process.readAllStandardOutput();
    QString outputString = QString::fromLocal8Bit(output);
    outputString.chop(1); // 移除最后一个字符（即换行符）


    //timperature he humdity
    ui->textEdit->append(outputString);

    QString temperature=outputString.mid(12,2);
    QString humidity=outputString.mid(15,2);
    // 在控制台输出 Python 进程的输出
    //qDebug() << outputString;
    ui->label_HTsensor->setText(temperature);
    ui->label_HTsensor->show();
    ui->label_HTsensor_2->setText(humidity);
    ui->label_HTsensor_2->show();
    int temperatureValue = temperature.toInt();
    int humidityValue = humidity.toInt();


    //zhengchang||baojing

    //duqu
    QString text_LT=ui->lineEdit_LT->text();
    QString text_HT=ui->lineEdit_HT->text();
    QString text_LH=ui->lineEdit_LH->text();
    QString text_HH=ui->lineEdit_HH->text();

    //zhuanhuan
    int Value_LT=text_LT.toInt();
    int Value_HT=text_HT.toInt();
    int Value_LH=text_LH.toInt();
    int Value_HH=text_HH.toInt();



    //wendu
    if(Value_HT<Value_LT)
    {
        ui->WDstate->setText("NULL");
        ui->WDstate->setStyleSheet("color: red;" + ui->label_redsensor->styleSheet());
    }
    else if(temperatureValue<Value_LT)
    {
        ui->WDstate->setText("温度过低");
        ui->WDstate->setStyleSheet("color: red;" + ui->label_redsensor->styleSheet());
    }
    else if(temperatureValue<=Value_HT)
    {
        ui->WDstate->setText("温度正常");
        ui->WDstate->setStyleSheet("color: green;" + ui->label_redsensor->styleSheet());
    }
    else if(temperatureValue>Value_HT)
    {
        ui->WDstate->setText("温度过高");
        ui->WDstate->setStyleSheet("color: red;" + ui->label_redsensor->styleSheet());
    }
    else
    {
        ui->WDstate->setText("NULL");
        ui->WDstate->setStyleSheet("color: red;" + ui->label_redsensor->styleSheet());
    }

    ui->WDstate->show();

    //shidu
    if(Value_HH<Value_LH)
    {
        ui->SDstate->setText("NULL");
        ui->SDstate->setStyleSheet("color: red;" + ui->label_redsensor->styleSheet());
    }
    else if(humidityValue<Value_LH)
    {
        ui->SDstate->setText("湿度过低");
        ui->SDstate->setStyleSheet("color: red;" + ui->label_redsensor->styleSheet());
    }
    else if(humidityValue<=Value_HH)
    {
        ui->SDstate->setText("湿度正常");
        ui->SDstate->setStyleSheet("color: green;" + ui->label_redsensor->styleSheet());
    }
    else if(humidityValue>Value_HH)
    {
        ui->SDstate->setText("湿度过高");
        ui->SDstate->setStyleSheet("color: red;" + ui->label_redsensor->styleSheet());
    }
    else
    {
        ui->SDstate->setText("NULL");
        ui->SDstate->setStyleSheet("color: red;" + ui->label_redsensor->styleSheet());
    }

    ui->SDstate->show();


    // 更新最大和最小值
//    static int minTemperature = temperatureValue;
//    static int maxTemperature = temperatureValue;
//    static int minHumidity = humidityValue;
//    static int maxHumidity = humidityValue;

    if (temperatureValue < minTemperature) {
        minTemperature = temperatureValue;
    }
    if (temperatureValue > maxTemperature) {
        maxTemperature = temperatureValue;
    }
    if (humidityValue < minHumidity) {
        minHumidity = humidityValue;
    }
    if (humidityValue > maxHumidity) {
        maxHumidity = humidityValue;
    }

}
void MainWindow::MPU6050()
{
    QProcess process;

    // 设置要执行的 Python 脚本路径和参数
    QString pythonPath = "python3";  // 或者使用完整的 Python 解释器路径
    QStringList arguments;
    arguments << "/root/Desktop/MPU6050/MP1.py";

    // 启动 Python 进程
    process.start(pythonPath, arguments);

    // 等待进程执行完成
    process.waitForFinished();

    // 读取进程的输出
    QByteArray output = process.readAllStandardOutput();
    QString outputString = QString::fromLocal8Bit(output);

    //six lines data
    QStringList lines = outputString.split("\n");
    if (lines.size() >= 6) {
        QString firstLine = lines[0];
        QString secondLine = lines[1];
        QString thirdLine = lines[2];
        QString fourthLine = lines[3];
        QString fifthLine = lines[4];
        QString sixthLine = lines[5];

    // 在控制台输出 Python 进程的输出


    //ui->MP6050_ax->setText(firstLine);
   // ui->MP6050_ax->show();
    //ui->MP6050_ay->setText(secondLine);
    //ui->MP6050_ay->show();
    //ui->MP6050_az->setText(thirdLine);
    //ui->MP6050_az->show();
    //ui->MP6050_wx->setText(fourthLine);
   // ui->MP6050_wx->show();
    //ui->MP6050_wy->setText(fifthLine);
    //ui->MP6050_wy->show();
    //ui->MP6050_wz->setText(sixthLine);
    //ui->MP6050_wz->show();
    }
}

void MainWindow::aliyuntest()
{
    QProcess process;

    // 设置要执行的 sh 脚本路径和参数
    QString pythonPath = "/bin/sh";  // 或者使用完整的 Python 解释器路径
    QStringList arguments;
    arguments << "/root/Desktop/aliyun/start.sh";

    // 启动 sh 进程
    process.start(pythonPath, arguments);

    // 等待进程执行完成
    process.waitForFinished();

    // 读取进程的输出
    QByteArray output = process.readAllStandardOutput();
    QString outputString = QString::fromLocal8Bit(output);
    qDebug() << outputString;
    ui->textEdit->append(outputString);

}

void MainWindow::dateandtime()
{
    QDateTime currentDateTime = QDateTime::currentDateTime();
    QString currentDateTimeString = currentDateTime.toString("yyyy-MM-dd hh:mm:ss");
    ui->time->setText(currentDateTimeString);
    ui->time->show();
}

